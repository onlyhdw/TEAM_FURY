

### تابع : [FURY](https://t.me/N1FURY) ###